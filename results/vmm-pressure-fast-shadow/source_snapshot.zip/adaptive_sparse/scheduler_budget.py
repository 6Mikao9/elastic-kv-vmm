"""MiniMax eager scheduler integration for budget-triggered demotion."""

from collections import Counter
from functools import wraps
from fractions import Fraction
import hashlib
import logging
import json
import os
from pathlib import Path
import time

from .adaptive_runtime import MigrationFatal
from .migration import (
    abort_demote, abort_promote, commit_demote, commit_promote, prepare_demote, prepare_promote,
)


SCHEDULER_SHA256 = "fc96ed4b680fdf55621a5397f844cfd4cbd30213f44eec8a888b7cce75cafe60"
LOG = logging.getLogger(__name__)


def _releasable(tracker, pages):
    counts = Counter(chunk for page in set(pages) for chunk in tracker.chunks(page))
    return {chunk for chunk, count in counts.items()
            if count == tracker.refs.get(chunk) and chunk in tracker.backing.mapped_chunks}


def _rank_demotions(rank_candidates):
    common = set.intersection(*(set(rank) for rank in rank_candidates))
    return sorted(common, key=lambda rid: (
        -Fraction(min(rank[rid][0] for rank in rank_candidates),
                  max(1, max(rank[rid][1] for rank in rank_candidates))), rid))


class SchedulerBudget:
    def __init__(self, budget, headroom, dwell, force_step, low=0, stable=2,
                 observe=16, promote_step=0, stats_path=None, byte_cap=512 << 20):
        self.budget = budget
        self.headroom = headroom
        self.dwell = dwell
        self.force_step = force_step
        self.low = low
        self.stable = stable
        self.observe = observe
        self.promote_step = promote_step
        self.promoted = False
        self.low_since = None
        self.stats_path = stats_path
        self.byte_cap = byte_cap
        self.residency_since = {}
        self.stats = {"demotions": 0, "promotions": 0, "migration_seconds": 0,
                      "transfer_bytes": 0, "released_bytes": 0, "growth_bytes": 0,
                      "max_observed_backed_bytes": 0, "reasons": {},
                      "rejected_cap": 0, "rejected_dwell": 0}
        self.steps = 0
        self.forced = False
        self.last_change = float("-inf")

    def publish(self):
        if self.stats_path is not None:
            self.stats_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.stats_path.with_suffix(".tmp")
            temporary.write_text(json.dumps(self.stats, indent=2), encoding="utf-8")
            temporary.replace(self.stats_path)

    def record(self, direction, reason, started, transfer, actual):
        self.stats[direction + "s"] += 1
        self.stats["migration_seconds"] += time.monotonic() - started
        self.stats["transfer_bytes"] += transfer
        self.stats["released_bytes" if direction == "demotion" else "growth_bytes"] += actual
        reasons = self.stats["reasons"]
        reasons[reason] = reasons.get(reason, 0) + 1
        self.publish()

    def observe_residency(self, batch, resident, now):
        current = {}
        for request in batch.reqs:
            state = request.kv.req_pool_idx in resident
            previous = self.residency_since.get(request.rid)
            current[request.rid] = (state, previous[1] if previous and previous[0] == state else now)
        self.residency_since = current

    def transfer_cost(self, request, pool):
        return request.kv.kv_committed_len * pool.layer_num * (
            pool.bytes_per_token_k + pool.bytes_per_token_v)

    def eligible(self, request, pool, now, forced):
        if forced:
            return True
        if self.transfer_cost(request, pool) > self.byte_cap:
            self.stats["rejected_cap"] += 1
            return False
        if now - self.residency_since[request.rid][1] < self.dwell:
            self.stats["rejected_dwell"] += 1
            return False
        return True

    def boundary(self, batch, coordinator, exchange, synchronize, *, prefill, now):
        tracker = coordinator.mem_pool_device.adaptive_vmm
        self.observe_residency(batch, coordinator._ekv_resident, now)
        if not prefill and not batch.is_empty():
            self.steps += 1
        force = (not prefill and not self.forced and self.force_step > 0
                 and self.steps >= self.force_step)
        force_promote = (not prefill and self.forced and not self.promoted and
                         self.promote_step > 0 and self.steps >= self.promote_step)
        backed = tracker.backing.backed_bytes
        self.stats["max_observed_backed_bytes"] = max(self.stats["max_observed_backed_bytes"], backed)
        if not prefill and not force and not force_promote and (
                not self.budget or self.steps % self.observe):
            return
        local = (backed, force, now - self.last_change >= self.dwell, force_promote)
        states = exchange(local)
        pressure = self.budget > 0 and max(item[0] for item in states) + (
            self.headroom if prefill else 0
        ) > self.budget
        force = all(item[1] for item in states)
        peak = max(item[0] for item in states) + (self.headroom if prefill else 0)
        if not self.low or peak >= self.low:
            self.low_since = None
        elif self.low_since is None:
            self.low_since = now
        stable = self.low_since is not None and now - self.low_since >= self.stable
        forced_up = all(item[3] for item in states)
        if not pressure and not force and (self.low or self.promote_step):
            can_promote = all(exchange(stable and local[2]))
            if forced_up or can_promote:
                self.promote(batch, coordinator, exchange, synchronize, forced_up, now)
            return
        if not force and not (
                pressure and all(item[2] for item in states)):
            return

        capacity = coordinator.padded_buffer_size
        page_size = coordinator.mem_pool_device.page_size
        resident = coordinator._ekv_resident
        requests = {}
        for request in batch.reqs:
            kv = request.kv
            if (kv.req_pool_idx not in resident or request.finished() or request.hisparse_staging
                    or kv.kv_committed_len != kv.kv_allocated_len
                    or kv.kv_committed_len <= capacity
                    or int(coordinator.req_device_buffer_size[kv.req_pool_idx])
                    or int(coordinator.req_to_host_pool_allocated_len[kv.req_pool_idx])):
                continue
            if not self.eligible(request, coordinator.mem_pool_device, now, force):
                continue
            logical = coordinator.req_to_token_pool.req_to_token[
                kv.req_pool_idx, capacity:kv.kv_committed_len:page_size]
            physical = coordinator.mem_pool_device.translate_loc_from_full_to_hisparse_device(logical)
            pages = [slot // page_size for slot in physical.tolist()]
            chunks = _releasable(tracker, pages)
            if chunks or force:
                requests[request.rid] = (request, chunks)
        metrics = {rid: (len(chunks) * tracker.chunk_bytes,
                         self.transfer_cost(request, coordinator.mem_pool_device))
                   for rid, (request, chunks) in requests.items()}
        for rid in _rank_demotions(exchange(metrics)):
            request, chunks = requests[rid]
            kv = request.kv
            started = time.monotonic()
            prepared = None
            error = None
            try:
                prepared = prepare_demote(coordinator, request, synchronize)
            except Exception as exc:
                error = exc
            if not all(exchange(prepared is not None)):
                if prepared is not None:
                    abort_demote(prepared)
                raise MigrationFatal("scheduler TP demotion preparation failed") from error

            def trim():
                if chunks & tracker.refs.keys():
                    raise MigrationFatal("predicted released chunks remain owned")
                synchronize()
                return tracker.backing.reclaim(chunks, synchronize=False) * tracker.chunk_bytes

            released = None
            try:
                before = tracker.backing.backed_bytes
                released = commit_demote(prepared, resident.remove, synchronize, trim)
                if released != before - tracker.backing.backed_bytes:
                    released = None
            except Exception as exc:
                error = exc
            releases = exchange(released)
            if any(type(value) is not int or value < 0 for value in releases):
                raise MigrationFatal("scheduler TP demotion commit failed") from error
            self.last_change = time.monotonic()
            self.forced |= force
            self.residency_since[rid] = (False, self.last_change)
            self.low_since = None
            pool = coordinator.mem_pool_device
            self.record("demotion", "forced_decode" if force else ("prefill_pressure" if prefill
                        else "decode_pressure"), started, kv.kv_committed_len * pool.layer_num *
                        (pool.bytes_per_token_k + pool.bytes_per_token_v), released)
            LOG.info("Adaptive demotion: boundary=%s forced=%s released_bytes_by_rank=%s",
                     "prefill" if prefill else "decode", force, releases)
            return


    def promote(self, batch, coordinator, exchange, synchronize, forced, now):
        pool = coordinator.mem_pool_device
        tracker = pool.adaptive_vmm
        physical = coordinator.token_to_kv_pool_allocator.hisparse_attn_allocator
        resident = coordinator._ekv_resident
        requests = {}
        for request in batch.reqs:
            kv = request.kv
            row, length = kv.req_pool_idx, kv.kv_committed_len
            if (row is None or row in resident or request.finished() or request.hisparse_staging
                    or length != kv.kv_allocated_len or length <= coordinator.device_buffer_size
                    or int(coordinator.req_device_buffer_size[row]) != coordinator.padded_buffer_size):
                continue
            if not self.eligible(request, pool, now, forced):
                continue
            pages = -(-length // pool.page_size)
            # Upper bound includes transient coexistence with the source hot buffer.
            if len(physical.free_pages) >= pages:
                available_pages = physical.free_pages[:pages]
            else:
                available_pages = physical.get_all_free_pages().sort().values[:pages]
            missing = set().union(*(tracker.chunks(page) for page in available_pages.tolist()))
            missing.difference_update(tracker.backing.mapped_chunks)
            ceiling = self.budget if forced else self.low
            if physical.available_size() < pages * pool.page_size or (
                    ceiling and tracker.backing.backed_bytes + len(missing) * tracker.chunk_bytes > ceiling):
                continue
            requests[request.rid] = request
        candidates = set(requests)
        for rank_ids in exchange(tuple(sorted(requests))):
            candidates.intersection_update(rank_ids)
        if not candidates:
            return
        request = requests[min(candidates)]
        started = time.monotonic()
        prepared = None
        error = None
        try:
            prepared = prepare_promote(coordinator, request, synchronize)
        except Exception as exc:
            error = exc
        if not all(exchange(prepared is not None)):
            if prepared is not None:
                abort_promote(prepared)
            raise MigrationFatal("scheduler TP promotion preparation failed") from error
        growth = None
        try:
            self.stats["max_observed_backed_bytes"] = max(
                self.stats["max_observed_backed_bytes"], tracker.backing.backed_bytes)
            growth = commit_promote(prepared, resident.add, synchronize)
        except Exception as exc:
            error = exc
        if any(type(value) is not int or value < 0 for value in exchange(growth)):
            raise MigrationFatal("scheduler TP promotion commit failed") from error
        self.last_change = time.monotonic()
        self.low_since = None
        self.promoted |= forced
        self.residency_since[request.rid] = (True, self.last_change)
        self.record("promotion", "forced_decode" if forced else "low_water_stable",
                    started, request.kv.kv_committed_len * pool.layer_num *
                    (pool.bytes_per_token_k + pool.bytes_per_token_v), growth)


def install_scheduler_budget():
    """Install before scheduler construction, after the residency hook."""
    budget = int(os.environ.get("EKV_ADAPTIVE_BUDGET_BYTES", "0"))
    headroom = int(os.environ.get("EKV_ADAPTIVE_PREFILL_HEADROOM_BYTES", "0"))
    force = int(os.environ.get("EKV_ADAPTIVE_FORCE_DECODE_STEP", "0"))
    dwell = float(os.environ.get("EKV_ADAPTIVE_DWELL_SECONDS", "1"))
    low = int(os.environ.get("EKV_ADAPTIVE_LOW_BYTES", "0"))
    stable = float(os.environ.get("EKV_ADAPTIVE_LOW_STABLE_SECONDS", "2"))
    observe = int(os.environ.get("EKV_ADAPTIVE_OBSERVE_STEPS", "16"))
    promote = int(os.environ.get("EKV_ADAPTIVE_FORCE_PROMOTE_STEP", "0"))
    stats_dir = os.environ.get("EKV_ADAPTIVE_STATS_DIR")
    cap = int(os.environ.get("EKV_ADAPTIVE_MIGRATION_BYTE_CAP", str(512 << 20)))
    if not budget and not force and not promote:
        return
    if (min(budget, headroom, force, dwell, low, stable, promote) < 0 or observe < 1 or cap < 1
            or (low and low >= budget) or (promote and (not force or promote <= force))):
        raise ValueError("adaptive scheduler settings must be nonnegative")
    import torch
    from sglang.srt.managers import scheduler
    from sglang.srt.model_executor.cuda_graph_config import cuda_graph_fully_disabled
    from sglang.srt.runtime_context import get_disagg, get_schedule, get_server_args, get_spec

    if hashlib.sha256(Path(scheduler.__file__).read_bytes()).hexdigest() != SCHEDULER_SHA256:
        raise RuntimeError("unaudited scheduler budget source")
    cls = scheduler.Scheduler
    if getattr(cls, "_ekv_adaptive_budget_installed", False):
        return

    def run(self, batch, prefill):
        coordinator = self.hisparse_coordinator
        if not hasattr(self, "_ekv_adaptive_budget"):
            if (coordinator is None or not coordinator.is_m3_hisparse
                    or not hasattr(coordinator, "_ekv_resident")
                    or not hasattr(coordinator.mem_pool_device, "adaptive_vmm")
                    or not cuda_graph_fully_disabled()
                    or not get_schedule().disable_overlap_schedule
                    or not get_server_args().disable_radix_cache
                    or get_disagg().disaggregation_mode != "null"
                    or get_spec().speculative_algorithm not in (None, "NONE")):
                raise RuntimeError("adaptive scheduler requires eager colocated MiniMax VMM residency")
            from sglang.srt.distributed.parallel_state import get_tensor_model_parallel_rank

            stats_path = (Path(stats_dir) / f"rank{get_tensor_model_parallel_rank():02d}.json"
                          if stats_dir else None)
            self._ekv_adaptive_budget = SchedulerBudget(
                budget, headroom, dwell, force, low, stable, observe, promote, stats_path, cap)

        def exchange(value):
            if coordinator.tp_world_size == 1:
                return (value,)
            replies = [None] * coordinator.tp_world_size
            torch.distributed.all_gather_object(replies, value, group=coordinator.tp_group)
            return replies

        self._ekv_adaptive_budget.boundary(
            batch, coordinator, exchange,
            lambda: torch.cuda.synchronize(coordinator.mem_pool_device.device),
            prefill=prefill, now=time.monotonic(),
        )

    prefill = cls.get_new_batch_prefill
    decode = cls.update_running_batch

    @wraps(prefill)
    def before_prefill(self, running_batch):
        if budget and (self.waiting_queue or self.chunked_req is not None):
            run(self, running_batch, True)
        return prefill(self, running_batch)

    @wraps(decode)
    def before_decode(self, batch):
        run(self, batch, False)
        return decode(self, batch)

    idle = cls.on_idle

    @wraps(idle)
    def on_idle(self):
        controller = getattr(self, "_ekv_adaptive_budget", None)
        if controller is not None and self.is_fully_idle():
            signature = tuple(controller.stats[key] for key in (
                "max_observed_backed_bytes", "rejected_cap", "rejected_dwell"))
            if getattr(controller, "_published", None) != signature:
                controller.publish()
                controller._published = signature
        return idle(self)

    cls.on_idle = on_idle
    cls.get_new_batch_prefill = before_prefill
    cls.update_running_batch = before_decode
    cls._ekv_adaptive_budget_installed = True
