"""Scheduler idle integration for the stock MiniMax HiSparse VMM arm."""

import hashlib
import json
from functools import wraps
from pathlib import Path
from time import perf_counter_ns

from .minimax_vmm import install_minimax_vmm


_SCHEDULER_HASH = "fc96ed4b680fdf55621a5397f844cfd4cbd30213f44eec8a888b7cce75cafe60"


def install_vmm_runtime(stats_dir):
    """Install in each scheduler process before constructing its worker."""
    from sglang.srt.managers import scheduler

    if getattr(scheduler.Scheduler, "_adaptive_vmm_idle_installed", False):
        return
    if hashlib.sha256(Path(scheduler.__file__).read_bytes()).hexdigest() != _SCHEDULER_HASH:
        raise RuntimeError("Unaudited MiniMax VMM scheduler")
    install_minimax_vmm()
    stats_dir = Path(stats_dir)
    stats_dir.mkdir(parents=True, exist_ok=True)
    original_idle = scheduler.Scheduler.on_idle

    @wraps(original_idle)
    def on_idle(self):
        allocator = self.token_to_kv_pool_allocator
        pool = getattr(allocator.get_kvcache(), "main_pool", None)
        tracker = getattr(pool, "adaptive_vmm", None)
        if tracker is not None and self.is_fully_idle() and len(tracker.pages) == 1:
            coordinator = self.hisparse_coordinator
            if coordinator is None:
                raise RuntimeError("Missing MiniMax HiSparse coordinator")
            if not coordinator.has_ongoing_staging():
                if tracker.stats()["reclaimable_bytes"]:
                    coordinator.wait_for_pending_backup()
                    tracker.trim_quiescent()
                parallel = scheduler.get_parallel()
                stats = {"tp_rank": parallel.tp_rank, "tp_size": parallel.tp_size,
                         "idle": True, **tracker.stats(), **tracker.backing.metrics,
                         "timestamp_monotonic_ns": perf_counter_ns()}
                if hasattr(coordinator, "_ekv_residency_stats"):
                    stats["request_residency"] = dict(coordinator._ekv_residency_stats)
                signature = {key: value for key, value in stats.items()
                             if key != "timestamp_monotonic_ns"}
                if signature != getattr(self, "_adaptive_vmm_last_stats", None):
                    target = stats_dir / f"tp-{parallel.tp_rank}.json"
                    temp = target.with_suffix(".tmp")
                    temp.write_text(json.dumps(stats, allow_nan=False) + "\n", encoding="utf-8")
                    temp.replace(target)
                    self._adaptive_vmm_last_stats = signature
        return original_idle(self)

    scheduler.Scheduler.on_idle = on_idle
    scheduler.Scheduler._adaptive_vmm_idle_installed = True
